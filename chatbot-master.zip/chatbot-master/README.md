# Simple Chatbot with JavaScript

Hello! This is just a simple "chatbot" using nothing but JavaScript. I put this in quotes because chatbots these days are way more sophisticated, using AI, Python, and a ton of different options for libraries and specification. 

This was simply an exercise during a coding bootcamp while learning beginner JavaScript

It is a good exercise for anyone interested in chatbots, JavaScript fundamentals such as if-then logic and conditionals, as well as some very simple HTML/CSS.

Enjoy!

I also wrote a blog post detailing this here:

https://dev.to/sylviapap/make-a-simple-chatbot-with-javascript-1gc